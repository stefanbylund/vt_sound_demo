Demonstration of vt_sound
=========================

The vt_sound_demo is a simple example program demonstrating how to use the
vt_sound (https://github.com/stefanbylund/vt_sound) C API for the Vortex
Tracker II player to play a PT3 module in the background.

The vt_sound_demo project is available on GitHub at:
https://github.com/stefanbylund/vt_sound_demo

Run the vt_sound_demo.tap file in a Sinclair ZX Spectrum emulator with AY-3-8912
sound chip support, e.g. ZEsarUX (https://sourceforge.net/projects/zesarux/).
